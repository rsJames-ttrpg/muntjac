# stub for pkg_a
__version__ = "1.0.0"
