# stub for pkg_b
__version__ = "1.0.0"
