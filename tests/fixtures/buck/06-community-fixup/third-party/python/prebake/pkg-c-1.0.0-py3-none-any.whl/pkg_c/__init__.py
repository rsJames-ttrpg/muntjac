# stub for pkg_c
__version__ = "1.0.0"
